# @darwin/guardian

## 0.3.2 — ۱۹ مهر ۱۴۰۵
- قاعدهٔ تازهٔ `DW-RTLNAV` (important): فلشِ قبلی/بعدی/بازگشت با `rotate-180`/`-scale-x-100`/`rtl:` برگردانده نشود — قانونِ جهت در RTL (منبع: منظومه؛ هادربون R39).

## 0.3.1 — ۱۱ مهر ۱۴۰۵
- `route-zod-auth`: پارامتر `authFlags` (پیش‌فرض `"i"` = همان رفتار 0.3.0). با `""` regex احراز هویت حساس به حروف است؛ کشف‌شده در تست برابری دِدرخت (گاردِ آن case-sensitive بود). `(?-i:)` در Node 22 نیست، پس راه دیگری نبود.

## 0.3.0 — ۱۱ مهر ۱۴۰۵
بستهٔ قواعد مشترک + `extends` (ADR 0003 §۵ و پیوست ۰٫۳). پروژه‌ای که `extends` ندارد بایت‌به‌بایت همان خروجی ۰٫۲ را می‌گیرد.
- **`rules/DW-*.json`** داخل همان tarball: هشت قاعدهٔ موج اول (DIALOG، COLOR، ANY، SECRET، HEADER، DIGITS، CLICK، ROUTE) با `origin` اجباری و `aliases` (کد هر پروژه). دو origin باگِ واقعی (DW-DIALOG از fi123 UI-04؛ DW-SECRET از باگ ۰۱ بلگرام)، شش‌تا convention با عبارت صادقانه.
- **`GuardianConfig.extends`**: `use` (DW-id → کد پروژه)، `override` (با `reason` اجباری؛ `null` برای برداشتنِ include/exclude/unless/lineUnless بسته؛ `params` برای چک‌ها)، `coexist` (هم‌زیستیِ صریح با قاعدهٔ دیگرِ پروژه زیر همان کد، با دلیل). کدِ تکراریِ بسته+پروژه ⇒ خطای پیکربندی.
- **چک‌های کل‌فایلِ پارامتری** (`src/checks/`): `persian-header`، `route-zod-auth`؛ نامشان در JSON (`check`)، منطقشان ثابت در پکیج. معافیتِ سطحِ فایل `guardian-ignore <کد پروژه>`.
- API: `loadPack()`، `listPack()`، `parsePack()`، `parsePackRule()`، `expandExtends()`.
- اعتبارسنجی بسته: بی‌origin، origin نامعتبر، regex خراب، id تکراری، aliases خالی، نام فایل ناهم‌خوان ⇒ شکست. تست ReDoS (خط ۲۰٬۰۰۰ نویسه‌ای زیر ۵۰ms) برای همهٔ الگوها.
- **یافتهٔ ReDoS:** الگوی R6/R16 (`placeholder="…کلمه…"` بی‌نقل‌قولِ بسته) روی خطِ بلند درجه‌دوم بود (۵۲ms/۲۰k)؛ نسخهٔ بسته با lookahead خطی است و هم‌ارز (تست).

## 0.2.0 — ۱۱ مهر ۱۴۰۵
قابلیت‌های ai123 که موتور ۰٫۱ نداشت (پیش‌فرض‌ها بی‌تغییر؛ دِدرخت و هادربون بدون تغییر کار می‌کنند):
- `Rule.codeOnly` + `commentLineSet` (کامنت `//`، بلاک، و `{/* */}` چندخطیِ JSX) و `stripComments` برای چک‌های کل‌فایل.
- `GuardianConfig.fileLevelIgnore`: «guardian-ignore CODE» هرجای فایل همهٔ نقض‌های آن کد را برمی‌دارد.
- `GuardianConfig.title` و `suspendedInfo` (فهرست قوانین معلق در گزارشِ پاک).
- از fi123: `contextWindow` ({before, after}؛ پیش‌فرض ۱۲/۵، fi123: ۱۲/۱۴)، ریشه‌هایی که خودِ **فایل**‌اند (`middleware.ts`)، `Rule.skill` («↳ راه‌حل: skill X» در گزارش/hook/JSON)، `baseline.failOn: "critical"` (ratchet فقط بحرانیِ جدید را مسدود می‌کند).
- baseline با قالب `counts`: ترتیبِ اسکن حفظ می‌شود (نه الفبایی) تا فایلِ موجودِ fi123 بایت‌به‌بایت یکی بماند.
- **`cliMain(config)`**: `scan.ts` پروژه باید از آن استفاده کند، نه `process.exit(code)`. `process.exit` بعد از console.log پروسه را پیش از خالی‌شدنِ stdout می‌کُشد و خروجیِ بزرگ (>۶۴KB، مثلاً `--json | …` روی ۴٬۴۰۰ نقض) در pipe بریده می‌شد؛ در هر هفت فورکِ قدیم هم بود. تست با ۵۰۰۰ نقض.

## 0.1.1 — ۱۱ مهر ۱۴۰۵
- **hook:** مسیرِ فایل و ریشهٔ پروژه با `realpath` مقایسه می‌شوند. قبلاً با لینکِ نمادین (`/tmp` → `/private/tmp`، worktree) فایل «بیرونِ پروژه» حساب می‌شد و hook **بی‌صدا** رد می‌شد (حتی نقض بحرانی). کشف‌شده در اولین آزمایشِ hook روی هادربون؛ تست جدید دارد.

## 0.1.0 — ۱۱ مهر ۱۴۰۵ (2026-10-03)
استخراج از ۷ فورک (هادربون، ai123، دِدرخت، fi123، گیرنمیاد، بلگرام، SmartDVR). پایه: دِدرخت (موتور/ratchet) + fi123/بلگرام (hook درست) + ai123 (تعلیق).
- موتور: قواعد خط‌به‌خط با پنجرهٔ unless/معافیت (۱۲ قبل تا ۵ بعد)، چک کل‌فایل، `guardian-ignore`، تعلیق قاعده، شدت تک‌منبع (`createManifest`).
- baseline/ratchet با دو راهبرد (`fingerprints`، `counts`)؛ critical هرگز baseline نمی‌شود.
- hook با معنای رسمی کلادکد (exit 2 / additionalContext).
- ۱۵ تست + تست برابری روی دِدرخت (۴۵ نقض یکسان).
- نیامد (بعدی): بستهٔ قواعد مشترک (۰٫۲)، مهاجرت هادربون/ai123/fi123، `createManifest` با audit knowledge، پورت پایتون (نه، بازنشسته می‌شود).
