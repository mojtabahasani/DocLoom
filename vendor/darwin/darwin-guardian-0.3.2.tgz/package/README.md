# @darwin/guardian

موتور واحد نگهبان کد: قواعد regex خط‌به‌خط، چک‌های کل‌فایل، `guardian-ignore`، baseline/ratchet، تعلیق قاعده، گزارش فارسی و hook کلادکد. بی‌وابستگی.
تصمیم‌ها: [ADR 0003](../../docs/adr/0003-guardian.md) · ورقهٔ شورا: [docs/council/guardian.md](../../docs/council/guardian.md).

**مرز:** موتور و قواعد مشترک اینجاست؛ **قواعد اختصاصی، شدت‌ها و چک‌های هر پروژه** در `scripts/guardian/` همان پروژه می‌مانند.

## استفادهٔ پروژه (لایهٔ نازک)
```ts
// scripts/guardian/config.ts
import type { GuardianConfig } from "@darwin/guardian";
export const config: GuardianConfig = {
  name: "MyProject",
  roots: ["src", "scripts"],            // یا تابع (root) => string[]
  rules: RULES,                          // [{ code, title, severity, include, exclude?, pattern, unless?, lineUnless?, message }]
  checks: CHECKS,                        // (rel, content) => Violation | Violation[] | null
  severityOf: manifest.severityOf,       // createManifest(...) — شدت تک‌منبع
  isSuspended: manifest.isSuspended,
  baseline: { format: "fingerprints" },  // یا "counts" (fi123)
};
// scan.ts:  cliMain(config)   ← نه process.exit (خروجی بزرگ در pipe بریده می‌شود)
// hook.ts:  hookMain(config)
```
`npx tsx scripts/guardian/scan.ts [فایل…] [--json] [--ratchet] [--update-baseline]`

## بستهٔ قواعد مشترک و `extends` (0.3)
هشت قاعدهٔ پرتکرار (`DW-DIALOG`، `DW-COLOR`، `DW-ANY`، `DW-SECRET`، `DW-HEADER`، `DW-DIGITS`، `DW-CLICK`، `DW-ROUTE`) به‌صورت **داده** در `rules/DW-*.json` همین پکیج‌اند
(با `origin` اجباری: bug/incident/convention، و `aliases` = کدِ هر پروژه). قاعدهٔ کل‌فایل فقط *نامِ* یک چکِ ثابت (`check`) و پارامتر می‌دهد؛ داده کد اجرا نمی‌کند.
```ts
export const config: GuardianConfig = {
  name: "Derakht", roots, rules: RULES, checks: CHECKS, severityOf, baseline: { format: "fingerprints" },
  extends: [{
    pack: "darwin",
    use: { "DW-DIALOG": "D11", "DW-SECRET": "D9" },            // قاعدهٔ بسته → کدِ همین پروژه (اثرانگشت baseline همان کد را دارد)
    override: { "DW-DIALOG": { include: /^(apps|packages)\/.+\.tsx?$/, reason: "فقط کد محصول، نه scripts" } },   // reason اجباری
    coexist: { D9: "قاعدهٔ دومِ D9 (رمزنگاری دستی) متمایز است" },   // فقط اگر پروژه زیر همان کد قاعدهٔ دیگری دارد
  }],
};
```
- قاعده با **کد پروژه** ساخته می‌شود و پیش از `rules` پروژه می‌آید؛ `guardian-ignore <کد پروژه>`، baseline و manifest دست‌نخورده‌اند. شدت از `severityOf` پروژه؛ نبود ⇒ شدتِ پیشنهادیِ بسته.
- همان کد هم در `use` و هم در `rules` پروژه ⇒ خطای پیکربندی (دوبار شمردن)، مگر با `coexist` و دلیل.
- `override` (`include/exclude/pattern/unless/lineUnless/codeOnly/message/params`؛ `null` = برداشتنِ مقدارِ بسته) بدون `reason` ⇒ خطا. چک‌های کل‌فایل از `params` پارامتر می‌گیرند.
- پارامتر چک `route-zod-auth`: `authFlags` (پیش‌فرض `"i"`؛ `""` = regex احراز هویت حساس به حروف).
- API: `loadPack()`، `listPack()` (برای میز/مستند: id، شدت، origin، کدِ هر پروژه)، `parsePackRule()`.
- پروژه‌ای که `extends` ندارد دقیقاً همان رفتار ۰٫۲ را دارد.

## hook (PostToolUse) — معنای رسمی کلادکد
🔴 → **exit 2** + stderr · 🟠/🟡 → exit 0 + `hookSpecificOutput.additionalContext` · پاک → بدون خروجی · خطای داخلی → exit 0. فقط نقض‌های **خارج از baseline** گزارش می‌شوند.
ثبت در `.claude/settings.json`: `hooks.PostToolUse[{ matcher: "Edit|Write|MultiEdit", hooks: [{ type: "command", command: "$CLAUDE_PROJECT_DIR/scripts/guardian/hook.sh" }] }]`.

## baseline
دو راهبرد موجود: `fingerprints` (`file::code::text`؛ هادربون/دِدرخت) و `counts` (`{file:{code:n}}`؛ fi123). critical هرگز baseline نمی‌شود (`critical: "allowed"` فقط برای مهاجرت).

## تضمین مهاجرت
[تست برابری](test/parity/README.md): موتور با config هر پروژه باید دقیقاً همان نقض‌های اسکنر فعلی را بدهد. دِدرخت: ۴۵ نقض/۱۵ قاعده یکسان.
